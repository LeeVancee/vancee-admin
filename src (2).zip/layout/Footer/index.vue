<template>
  <div class="footer flx-center">
    <a href="http://beian.miit.gov.cn/" target="_blank">
      2022 © Vancee-Admin By Vancee Technology.
    </a>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
@import './index.scss';
</style>
