// ? 全局不动配置项 只做导出不做修改

// * 首页地址（默认）
export const HOME_URL: string = '/home/index'

// * Tabs（白名单地址）
export const TABS_WHITE_LIST: string[] = ['/403', '/404', '/500', '/layout', '/login']

// * 高德地图key
export const MAP_KEY: string = '20f12aae660c04de86f993d3eff590a0'
