export const ACCESS_TOKEN: string = 'Vancee_ACCESS_TOKEN'
export const USER_INFO: string = 'Vancee_USER_INFO'
