export const ACCESS_TOKEN: string = "VANCEE_ACCESS_TOKEN"; 
export const USER_INFO: string = "VANCEE_USER_INFO"; 