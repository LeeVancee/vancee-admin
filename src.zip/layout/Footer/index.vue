<template>
  <div class="footer flx-center">
    <a href="#" target="_blank"> 2022 © Vancee-Admin By shokuhou Technology. </a>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
@import "./index.scss";
</style>