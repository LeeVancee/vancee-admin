declare module 'nprogress'
declare module 'js-md5'

// * Menu
declare namespace Menu {
  interface MenuOptions {
    path: string
    title: string
    icon?: string
    isLink?: string
    close?: boolean
    children?: MenuOptions[]
  }
}

declare global {
  interface Window {
    navigator: {
      [key: string]: any
    }
  }
}
