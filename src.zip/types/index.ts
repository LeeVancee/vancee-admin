export interface LoginFrom {
  username: string;
  password: string;
}

export interface LoginFormExpose {
  count: number;
  consoleNumber: () => void;
}